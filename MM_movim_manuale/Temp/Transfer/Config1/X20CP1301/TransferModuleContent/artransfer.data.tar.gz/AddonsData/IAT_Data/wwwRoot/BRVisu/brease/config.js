define({

    font: 'Arial, Helvetica, sans-serif',
    undefinedTextReturnValue: 'undefined key',
    visu: {
        activityCount: false,
        moveThreshold: 20
    },
    ContentCaching: {
        preserveOldValues: true
    },
    WidgetData: {
        renderingPolicy: 'default'
    },
    themeFolder: 'release/'
});
